function showmenu(){
    let menu =  document.querySelector('.menu');
    let body = document.getElementById('body');
    let button = document.querySelector('.nav-botton');
    let link = document.querySelector('.list')
    let no = document.getElementsByClassName('at')

    if(Number(body.style.width) < 1024){
        if(menu.style.width == '70vw'){
            menu.style.width = '0px';
            menu.style.visibility = 'hidden'
            button.style.transform = 'rotate(0deg)'
            link.style.opacity = '0'
        }
        else{
            menu.style.width = '70vw'
            menu.style.visibility = 'visible'
            button.style.transform = 'rotate(90deg)';
            link.style.opacity = '1 '
        }
    }

    
}
